
#!/usr/bin/env bash
# Requires GitHub CLI: https://cli.github.com/
set -e

REPO=${1:-origin}

# Create standard labels
labels=(
  "bug:#d73a4a:Something isn't working"
  "enhancement:#a2eeef:New feature or request"
  "documentation:#0075ca:Improvements or additions to docs"
  "chore:#cfd3d7:Build/infra tasks"
  "good-first-issue:#7057ff:Good for newcomers"
  "help-wanted:#008672:Extra attention is needed"
  "feat:#0e8a16:Feature work"
  "fix:#d73a4a:Bug fix"
)

for entry in "${labels[@]}"; do
  IFS=":" read -r name color desc <<< "$entry"
  echo "Creating label: $name"
  gh label create "$name" -c "$color" -d "$desc" || echo "Label $name may already exist."
done
