
# Contributing to Study Mate

Thanks for your interest in contributing! This guide explains how we collaborate.

## Workflow
1. Branch from `main`: `git checkout -b feature/<name>`
2. Commit using Conventional Commits: `type(scope): summary`
3. Open a draft Pull Request early and link an issue
4. Ensure CI passes (analyze + test)
5. Request review (CODEOWNERS will auto-request)
6. Address feedback; resolve all conversations
7. Squash merge; delete the branch

## Branch naming
- `feature/<topic>` – new features
- `fix/<bug>` – bug fixes
- `chore/<task>` – tooling/infra
- `docs/<topic>` – docs changes
- `test/<scope>` – tests only

## Commit message style
```
feat(ask): add citations panel
fix(ocr): handle skewed pages to avoid crash
chore(ci): enable cache for pub get
refactor(rag): extract chunker
```

## Reviews
- Keep PRs focused and under ~300 lines where possible
- Provide screenshots/GIFs for UI changes
- Reviewer checklist: correctness, performance, accessibility, tests, docs

## Testing
- Add/Update unit tests for business logic
- For UI changes, attach screenshots/GIFs

## Releases
- Version tags: `vX.Y.Z`
- Release notes are drafted automatically via Release Drafter
