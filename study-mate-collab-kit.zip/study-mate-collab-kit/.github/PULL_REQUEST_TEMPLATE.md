
## Summary
What does this PR change?

## Type
- [ ] feat
- [ ] fix
- [ ] refactor
- [ ] chore
- [ ] docs
- [ ] test

## Changes
- Bullet the key changes

## Screenshots / Demos (if UI)
<!-- attach before/after or GIF -->

## Tests
- [ ] Added/updated tests
- [ ] Manually tested on device/emulator

## Checklist
- [ ] Linked issue(s): #
- [ ] CI passes (analyze + test)
- [ ] All conversations resolved
