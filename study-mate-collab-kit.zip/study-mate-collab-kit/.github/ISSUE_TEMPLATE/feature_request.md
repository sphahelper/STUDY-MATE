
---
name: Feature request
about: Propose an enhancement
labels: enhancement
---

**Problem**
What user problem are we solving?

**Proposal**
What should we build? (scope)

**Acceptance Criteria**
- [ ] ...
- [ ] ...

**Out of scope**
What we will not do (for now).
