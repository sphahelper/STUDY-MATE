
---
name: Bug report
about: Report a problem
labels: bug
---

**Describe the bug**
A clear description of the bug.

**Steps to Reproduce**
1. ...
2. ...

**Expected behavior**
What should happen?

**Screenshots/Logs**
If applicable, add screenshots or logs.

**Environment**
- Device/OS:
- App version/commit:

**Additional context**
Add any other context about the problem here.
